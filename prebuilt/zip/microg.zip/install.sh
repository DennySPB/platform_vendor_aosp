#!/sbin/sh

### GLOBAL VARIABLES ###

RECOVERY_API_VER="$2"
RECOVERY_PIPE="$3"
ZIP_FILE="$4"
TMP_PATH="$5"

INSTALLER=1
CPU=false
CPU64=false
LEGACY_ARM=false
LEGACY_ANDROID=false
OLD_ANDROID=false
SYS_ROOT_IMAGE=''
SYS_PATH='/system'
ZIP_PATH=false

### FUNCTIONS ###

# Message related functions
ui_msg()
{
  echo -e "ui_print $1\nui_print" >> $RECOVERY_PIPE
}

ui_msg_sameline_start()
{
  echo -n "ui_print $1" >> $RECOVERY_PIPE
}

ui_msg_sameline_end()
{
  echo -e " $1\nui_print" >> $RECOVERY_PIPE
}

ui_debug()
{
  echo "$1"
}

ui_error()
{
  >&2 echo "$1"
  ui_msg "$1"
  exit 80
}

# Error checking functions
validate_return_code()
{
  if [[ "$1" != 0 ]]; then ui_error "ERROR: $2"; fi
}

# Mounting related functions
is_mounted()
{
  case `mount` in
    *" $1 "*) return 0;;  # Mounted
  esac;
  return 1  # NOT mounted
}

is_mounted_read_write()
{
  mount | grep " $1 " | head -n1 | grep -qi -e "[(\s,]rw[\s,)]"
}

get_mount_status()
{
  local mount_line=$(mount | grep " $1 " | head -n1)
  if [[ -z $mount_line ]]; then return 1; fi  # NOT mounted
  if echo "$mount_line" | grep -qi -e "[(\s,]rw[\s,)]"; then return 0; fi  # Mounted read-write (RW)
  return 2  # Mounted read-only (RO)
}

remount_read_write()
{
  mount -v -o remount,rw "$1" "$1"
}

remount_read_only()
{
  mount -v -o remount,ro "$1" "$1"
}

# Getprop related functions
getprop()
{
  test -e '/sbin/getprop' && /sbin/getprop "ro.${1}" || grep "^ro\.${1}=" '/default.prop' | head -n1 | cut -d '=' -f 2
}

build_getprop()
{
  grep "^ro\.${1}=" "${TMP_PATH}/build.prop" | head -n1 | cut -d '=' -f 2
}

# String related functions
is_substring()
{
  case "$2" in
    *"$1"*) return 0;;  # Found
  esac;
  return 1  # NOT found
}

# Extraction related functions
package_extract_file()
{
  mkdir -p -m 0755 "$(dirname "$2")"
  unzip -opq "$ZIP_FILE" "$1" > "$2"
  validate_return_code "$?" "Failed to extract the file '$1' from the archive"
}

custom_package_extract_dir()
{
  mkdir -p -m 0755 "$2"
  unzip -oq "$ZIP_FILE" "$1/*" -d "$2"
  validate_return_code "$?" "Failed to extract the files from the folder '$1' of the archive"
}

zip_extract_dir()
{
  mkdir -p -m 0755 "$3"
  unzip -oq "$1" "$2/*" -d "$3"
  validate_return_code "$?" "Failed to extract the files from the folder '$2' of the archive '$1'"
}

# Permission related functions
set_perm()
{
  local uid="$1"; local gid="$2"; local mod="$3"
  shift 3
  chown $uid:$gid "$@"
  chmod $mod "$@"
}

set_std_perm_recursive()  # Use it only if you know your version of 'find' handle spaces correctly
{
  find "$1" -type d -exec chmod 0755 '{}' + -o -type f -exec chmod 0644 '{}' +
  validate_return_code "$?" 'Failed to set permissions recursively'
}

# Hash related functions
verify_hash()
{
  local file_name="$1"
  local hash="$2"
  local file_hash=$(sha1sum "$file_name" | cut -d ' ' -f 1)

  if [[ $hash != "$file_hash" ]]; then return 1; fi  # Failed
  return 0  # Success
}

# File related functions
create_dir()
{
  mkdir -p -m 0755 "$1"
  chown 0:0 "$1"
}

delete_recursive()
{
  rm -rf "$@"
  validate_return_code "$?" 'Failed to delete files'
}

# Other
remove_ext()
{
  local str="$1"
  echo "${str%.*}"
}

# Test
find_test()  # This is useful to test 'find' - if every file/folder, even the ones with spaces, is displayed in a single line then your version is good
{
  find "$1" -type d -exec echo FOLDER: '{}' ';' -o -type f -exec echo FILE: '{}' ';' | while read x; do echo "$x"; done
}

### CODE ###

if ! is_mounted '/system'; then
  mount '/system'
  if ! is_mounted '/system'; then ui_error 'ERROR: /system cannot be mounted'; fi
fi

SYS_ROOT_IMAGE=$(getprop 'build.system_root_image')
if [[ -z $SYS_ROOT_IMAGE ]]; then
  SYS_ROOT_IMAGE=false;
elif [[ $SYS_ROOT_IMAGE == true && -d '/system/system' ]]; then
  SYS_PATH='/system/system';
fi

cp -pf "${SYS_PATH}/build.prop" "${TMP_PATH}/build.prop"  # Cache the file for faster access

PRIVAPP_PATH="${SYS_PATH}/app"
if [[ -d "${SYS_PATH}/priv-app" ]]; then PRIVAPP_PATH="${SYS_PATH}/priv-app"; fi  # Detect the position of the privileged apps folder

API=$(build_getprop 'build\.version\.sdk')
if [[ $API -ge 21 ]]; then
  :  ### New Android versions
elif [[ $API -ge 19 ]]; then
  OLD_ANDROID=true
elif [[ $API -ge 9 ]]; then
  LEGACY_ANDROID=true
  OLD_ANDROID=true
elif [[ $API -ge 1 ]]; then
  ui_error 'ERROR: Your Android version is too old'
else
  ui_error 'ERROR: Invalid API level'
fi

ABI_LIST=','$(build_getprop 'product\.cpu\.abi')','$(build_getprop 'product\.cpu\.abi2')','$(build_getprop 'product\.cpu\.abilist')','
if is_substring ',x86,' "$ABI_LIST"; then
  CPU='x86'
elif is_substring ',armeabi-v7a,' "$ABI_LIST"; then
  CPU='armeabi-v7a'
elif is_substring ',armeabi,' "$ABI_LIST"; then
  CPU='armeabi'
fi

if is_substring ',x86_64,' "$ABI_LIST"; then
  CPU64='x86_64'
elif is_substring ',arm64-v8a,' "$ABI_LIST"; then
  CPU64='arm64-v8a'
fi

if is_substring ',armeabi,' "$ABI_LIST" && ! is_substring ',armeabi-v7a,' "$ABI_LIST"; then LEGACY_ARM=true; fi

ZIP_PATH=$(dirname "$ZIP_FILE")

# Info
ui_msg '---------------------------'
ui_msg 'microG unofficial installer'
ui_msg 'v1.0.17 beta'
ui_msg '(by ale5000 modified by DennySPb)'
ui_msg '---------------------------'
ui_msg ''
ui_msg "API: ${API}"
ui_msg "Detected CPU: ${CPU}"
ui_msg "Detected 64-bit CPU: ${CPU64}"
ui_msg "System root image: ${SYS_ROOT_IMAGE}"
ui_msg "System path: ${SYS_PATH}"
ui_msg "Privileged apps: ${PRIVAPP_PATH}"
ui_msg ''

if [[ $CPU == false && $CPU64 == false ]]; then
  ui_error 'ERROR: Unsupported CPU'
fi

# Check the existance of the vendor libraries folders
if [[ $OLD_ANDROID == true ]]; then
  if [[ ! -d "${SYS_PATH}/vendor" ]]; then
    ui_error 'ERROR: Missing vendor folder'
  fi

  if [[ $CPU != false && ! -d "${SYS_PATH}/vendor/lib" ]]; then create_dir "${SYS_PATH}/vendor/lib"; fi
  if [[ $CPU64 != false && ! -d "${SYS_PATH}/vendor/lib64" ]]; then create_dir "${SYS_PATH}/vendor/lib64"; fi
fi

ui_msg 'Installing files...'
#custom_package_extract_dir 'files' "${TMP_PATH}"

ui_msg_sameline_start 'Verifying files...'
if verify_hash "${TMP_PATH}/files/priv-app/GmsCore.apk" 'c684419a7223cb1a9546963bc1a7a2b9a00522be' &&
   verify_hash "${TMP_PATH}/files/priv-app-kk/GmsCore.apk" '9a71f98ffb006b530e9268441b1b5089a64191d3' &&  # Remove when bug #379 is fixed
   verify_hash "${TMP_PATH}/files/priv-app/GoogleServicesFramework.apk" 'f9907df2e2c8fd20cd2e928821641fa01fca09ce' &&
   verify_hash "${TMP_PATH}/files/priv-app/DroidGuard.apk" 'fa6267bee3f73d248d1110be53d66736aa4fece0' &&
   verify_hash "${TMP_PATH}/files/priv-app/Phonesky.apk" 'd78b377db43a2bc0570f37b2dd0efa4ec0b95746' &&
   verify_hash "${TMP_PATH}/files/app/IchnaeaNlpBackend.apk" '19b286a12a4902b7627c04cb54bdda63af494696' &&
   verify_hash "${TMP_PATH}/files/app/NominatimGeocoderBackend.apk" '1bdb0472f3d113c6faeb3b6a781369ed1d012df1' &&
   ###verify_hash "${TMP_PATH}/files/app/PlayGames.apk" 'c99c27053bf518dd3d08449e9478b43de0da50ed' &&
   verify_hash "${TMP_PATH}/files/priv-app/FDroidPrivilegedExtension.apk" '075a81cd2b1449bb8e3db883c64778e44f3ce342' &&
   verify_hash "${TMP_PATH}/files/framework/com.google.android.maps.jar" '14ce63b333e3c53c793e5eabfd7d554f5e7b56c7' &&
   verify_hash "${TMP_PATH}/files/etc/permissions/com.google.android.maps.xml" '05b2b8685380f86df0776a844b16f12137f06583' &&
   verify_hash "${TMP_PATH}/files/etc/permissions/features.xml" '1eb8c90eeed31d6124710662e815aedc1b213c25' &&
   verify_hash "${TMP_PATH}/files/app-legacy/LegacyNetworkLocation.apk" '8121295640985fad6c5b98890a156aafd18c2053'
then
  ui_msg_sameline_end 'OK'
else
  ui_msg_sameline_end 'ERROR'
  ui_error 'ERROR: Verification failed'
fi

ui_debug 'Extracting libs...'
#create_dir "${TMP_PATH}/libs"
#zip_extract_dir "${TMP_PATH}/files/priv-app/GmsCore.apk" 'lib' "${TMP_PATH}/libs"

ui_debug 'Setting permissions...'
set_std_perm_recursive "${TMP_PATH}/files"
set_std_perm_recursive "${TMP_PATH}/libs"

# Clean some Google Apps and previous installations
. "${TMP_PATH}/uninstall.sh"

# Installing
ui_msg 'Installing...'
if [[ $OLD_ANDROID != true ]]; then
  # Move apps into subdirs
  for entry in "${TMP_PATH}/files/priv-app"/*; do
    path_without_ext=$(remove_ext "$entry")

    create_dir "$path_without_ext"
    mv -f "$entry" "$path_without_ext"/
  done
else
  cp -rpf "${TMP_PATH}/files/priv-app-kk/GmsCore.apk" "${TMP_PATH}/files/priv-app/GmsCore.apk"  # Remove when bug #379 is fixed
fi

cp -rpf "${TMP_PATH}/files/priv-app"/* "${PRIVAPP_PATH}/"
cp -rpf "${TMP_PATH}/files/app"/* "${SYS_PATH}/app/"
cp -rpf "${TMP_PATH}/files/framework"/* "${SYS_PATH}/framework/"
cp -rpf "${TMP_PATH}/files/etc/permissions"/* "${SYS_PATH}/etc/permissions/"

if [[ $LEGACY_ANDROID == true ]]; then
  cp -rpf "${TMP_PATH}/files/app-legacy"/* "${SYS_PATH}/app/"
fi

# Installing libs
ui_msg 'Installing libs...'
if [[ $OLD_ANDROID != true ]]; then
  # The name of the following architectures remain unchanged: x86, x86_64, mips, mips64
  mv -f "${TMP_PATH}/libs/lib/arm64-v8a/" "${TMP_PATH}/libs/lib/arm64"
  if [[ $LEGACY_ARM != true ]]; then
    mv -f "${TMP_PATH}/libs/lib/armeabi-v7a/" "${TMP_PATH}/libs/lib/arm"
    rm -rf "${TMP_PATH}/libs/lib/armeabi"
  else
    mv -f "${TMP_PATH}/libs/lib/armeabi/" "${TMP_PATH}/libs/lib/arm"
    rm -rf "${TMP_PATH}/libs/lib/armeabi-v7a"
  fi

  create_dir "${PRIVAPP_PATH}/GmsCore/lib"
  cp -rpf "${TMP_PATH}/libs/lib"/* "${PRIVAPP_PATH}/GmsCore/lib/"
else
  if [[ $CPU != false ]]; then
    cp -rpf "${TMP_PATH}/libs/lib/${CPU}"/* "${SYS_PATH}/vendor/lib/"
  fi
  if [[ $CPU64 != false ]]; then
    cp -rpf "${TMP_PATH}/libs/lib/${CPU64}"/* "${SYS_PATH}/vendor/lib64/"
  fi
fi

# Install survival script
if [[ -d "${SYS_PATH}/addon.d" ]]; then
  if [[ $LEGACY_ANDROID == true ]]; then
    :  ### Skip it
  elif [[ $OLD_ANDROID == true ]]; then
    :  ### Not ready yet #cp -rpf "${TMP_PATH}/files/addon.d/00-1-microg-k.sh" "${SYS_PATH}/addon.d/00-1-microg.sh"
  else
    ui_msg 'Installing survival script...'
    cp -rpf "${TMP_PATH}/files/addon.d/00-1-microg.sh" "${SYS_PATH}/addon.d/00-1-microg.sh"
  fi
fi

umount '/system'

# Disable Play Store self update
if [[ $OLD_ANDROID == true ]]; then
  if ! is_mounted '/data'; then
    mount '/data'
    if ! is_mounted '/data'; then ui_error 'ERROR: /data cannot be mounted'; fi
  fi

  if [[ -d '/data/app' ]]; then
    mkdir -p -m 0000 '/data/app/com.android.vending-1.apk'
  fi

  umount '/data'
fi

ui_msg 'Done.'
